# AI Customer Support Assistant

A runnable portfolio MVP for a fictional online store. It includes a chat UI, FAQ-grounded answers, issue categorization, escalation, support ticket creation, and SQLite persistence.

## Features
- Browser-based support chat with suggested questions.
- FAQ matching for shipping, returns, refunds, tracking, support hours, and payments.
- Safe fallback when a question cannot be answered from the demo policy.
- Issue category and priority classification.
- Support ticket form with generated ticket ID.
- SQLite ticket persistence (`support_tickets.db` is created automatically).
- Optional Gemini responses; demo mode works without an API key.
- Health endpoint and FastAPI interactive API docs.

## Run on Windows (PowerShell)
1. Install Python 3.10 or newer.
2. Extract the project folder.
3. Open PowerShell in this folder.
4. Create a virtual environment:
   ```powershell
   py -m venv .venv
   ```
5. Install dependencies:
   ```powershell
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   ```
6. Optional: configure Gemini. Copy `.env.example` to `.env`, then set `USE_GEMINI=true` and add your Google AI Studio API key. Keep the key private. Without this step the app runs in demo mode.
   ```powershell
   Copy-Item .env.example .env
   ```
7. Start the app:
   ```powershell
   .\.venv\Scripts\python.exe -m uvicorn main:app --reload
   ```
8. Open http://127.0.0.1:8000
9. API docs: http://127.0.0.1:8000/docs
10. Health check: http://127.0.0.1:8000/health

Stop the server with Ctrl+C.

## Quick tests
Try these in the chat:
- `How long does shipping take?`
- `What is your return policy?`
- `When will my refund arrive?`
- `Where is my order?` (should avoid inventing a live order status)
- `I think my card was charged twice` (should recommend human escalation)

Create a ticket from the Contact Support form. Restart the app and submit another ticket to confirm the SQLite file retains saved requests.

## API endpoints
- `GET /health` — app status
- `GET /api/faqs` — sample FAQ data
- `POST /api/chat` — answer and classify a customer question
- `POST /api/tickets` — create a support ticket
- `GET /api/tickets` — list recent tickets (demo-only; not authenticated)

Example chat request:
```json
{
  "message": "How long does shipping take?"
}
```

## Optional Gemini mode
Set in `.env`:
```dotenv
USE_GEMINI=true
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```
Restart the app after changing `.env`. If Gemini is unavailable or the key/quota fails, the app falls back to the FAQ-based demo response.

## Business use case
Small businesses can automate repetitive first-line questions and triage requests that require a person. The current data is fictional and does not connect to a real order, payment, or email system.

## Limitations and security
- This is a local portfolio demo, not a production customer-support system.
- `/api/tickets` is intentionally unauthenticated for local demonstration; do not expose it publicly without authentication, authorization, rate limits, privacy controls, and secure deployment.
- Do not submit real customer data or secrets to an AI service without authorization.
- No email is sent; tickets are saved locally to SQLite.
- AI responses may be wrong. Review before acting on account, billing, or refund issues.
