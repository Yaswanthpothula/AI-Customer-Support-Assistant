import os
import re
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

load_dotenv()

APP_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("DATABASE_PATH", str(APP_DIR / "support_tickets.db")))
COMPANY_NAME = os.getenv("COMPANY_NAME", "BrightCart Demo Store")
USE_GEMINI = os.getenv("USE_GEMINI", "false").strip().lower() in {"1", "true", "yes"}
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()

app = FastAPI(
    title="AI Customer Support Assistant",
    description="FAQ-grounded customer support demo with ticket creation, escalation, and optional Gemini responses.",
    version="1.0.0",
)

FAQS = [
    {
        "id": "shipping",
        "title": "Shipping time",
        "keywords": ["shipping", "delivery", "deliver", "arrive", "dispatch", "ship"],
        "answer": "Standard shipping usually takes 3–5 business days after dispatch. Delivery times are estimates and may vary by location.",
    },
    {
        "id": "returns",
        "title": "Returns policy",
        "keywords": ["return", "send back", "exchange", "unused", "wrong size"],
        "answer": "Unused products can be returned within 30 days of purchase with proof of purchase. Please contact support to confirm eligibility before sending an item back.",
    },
    {
        "id": "refunds",
        "title": "Refund timing",
        "keywords": ["refund", "money back", "reimbursement", "credited"],
        "answer": "Once a return is approved, refunds are generally processed within 5–7 business days. Your bank or payment provider may take additional time to display the refund.",
    },
    {
        "id": "tracking",
        "title": "Order tracking",
        "keywords": ["track", "tracking", "where is my order", "order status", "package"],
        "answer": "Use the tracking link in your order confirmation email to check your delivery status. This demo does not connect to real order systems, so I cannot look up an individual order.",
    },
    {
        "id": "support_hours",
        "title": "Support hours",
        "keywords": ["hours", "open", "opening", "contact support", "support team", "business hours"],
        "answer": "The demo support team is available Monday–Friday, 9:00 AM–5:00 PM IST.",
    },
    {
        "id": "payment",
        "title": "Payment methods",
        "keywords": ["payment", "pay", "card", "upi", "transaction", "charged"],
        "answer": "This sample store accepts common online payment methods at checkout. This demo cannot inspect actual transactions or confirm whether a payment succeeded.",
    },
]

ESCALATION_KEYWORDS = [
    "fraud", "scam", "charged twice", "double charged", "legal", "lawyer",
    "data breach", "stolen card", "unauthorized", "urgent", "angry",
    "complaint", "manager", "human", "agent", "speak to someone",
]

class ChatRequest(BaseModel):
    message: str = Field(min_length=2, max_length=2000)
    customer_name: Optional[str] = Field(default=None, max_length=100)
    customer_email: Optional[str] = Field(default=None, max_length=254)

class TicketRequest(BaseModel):
    message: str = Field(min_length=2, max_length=2000)
    customer_name: Optional[str] = Field(default=None, max_length=100)
    customer_email: Optional[str] = Field(default=None, max_length=254)
    category: str = Field(default="other", max_length=50)
    priority: str = Field(default="normal", max_length=20)
    summary: str = Field(default="Customer requested support", max_length=500)

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                customer_name TEXT,
                customer_email TEXT,
                category TEXT NOT NULL,
                priority TEXT NOT NULL,
                status TEXT NOT NULL,
                summary TEXT NOT NULL,
                original_message TEXT NOT NULL,
                assistant_reply TEXT NOT NULL
            )
        """)
        conn.commit()

init_db()

def tokenize(text: str):
    return set(re.findall(r"[a-z0-9']+", text.lower()))

def find_faq(message: str):
    text = message.lower()
    tokens = tokenize(message)
    best, best_score = None, 0
    for faq in FAQS:
        score = 0
        for kw in faq["keywords"]:
            if " " in kw:
                if kw in text:
                    score += 3
            elif kw in tokens:
                score += 2
        if score > best_score:
            best, best_score = faq, score
    return (best, best_score) if best_score >= 2 else (None, 0)

def classify_issue(message: str) -> str:
    faq, _ = find_faq(message)
    if faq:
        return faq["id"]
    text = message.lower()
    if any(k in text for k in ["invoice", "billing", "charged", "payment", "transaction"]):
        return "billing"
    if any(k in text for k in ["broken", "damaged", "defect", "not working"]):
        return "product_issue"
    if any(k in text for k in ["account", "login", "password", "sign in"]):
        return "account"
    if any(k in text for k in ["complaint", "manager", "angry", "unhappy"]):
        return "complaint"
    return "other"

def needs_escalation(message: str, faq, score: int) -> bool:
    text = message.lower()
    if any(k in text for k in ESCALATION_KEYWORDS):
        return True
    if faq is None or score < 2:
        return True
    if any(k in text for k in ["my order", "order number", "my account", "my payment", "my refund"]):
        return True
    return False

def gemini_answer(message: str, faq, escalate: bool) -> Optional[str]:
    if not (USE_GEMINI and GEMINI_API_KEY):
        return None
    try:
        from google import genai
        client = genai.Client(api_key=GEMINI_API_KEY)
        faq_context = "\n".join(f"- {f['title']}: {f['answer']}" for f in FAQS)
        prompt = f"""You are the customer support assistant for {COMPANY_NAME}, a fictional demo store.
Answer using only the approved policy context below. Do not invent order status, account details, refunds, prices, or policies.
If the policy does not answer the user's specific question, say you cannot verify it and recommend a support ticket.
Be concise, friendly, and clear. Do not ask for passwords, full card numbers, or sensitive authentication data.
Approved policy context:
{faq_context}
User message: {message}
Escalation is {'recommended' if escalate else 'not currently indicated'}.
Return only the customer-facing reply."""
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
        return (response.text or "").strip() or None
    except Exception:
        # Keep the product usable if the provider is unavailable or quota is exhausted.
        return None

def create_ticket(message: str, customer_name=None, customer_email=None, category="other",
                  priority="normal", summary="Customer requested support", assistant_reply=""):
    ticket_id = "BC-" + uuid.uuid4().hex[:8].upper()
    with connect_db() as conn:
        conn.execute("""
            INSERT INTO tickets
            (id, created_at, customer_name, customer_email, category, priority, status, summary, original_message, assistant_reply)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (ticket_id, utc_now(), customer_name, customer_email, category, priority,
              "open", summary, message, assistant_reply))
        conn.commit()
    return ticket_id

def compose_reply(message: str):
    faq, score = find_faq(message)
    category = classify_issue(message)
    escalation = needs_escalation(message, faq, score)
    priority = "high" if any(k in message.lower() for k in ["urgent", "fraud", "stolen", "unauthorized", "charged twice", "data breach"]) else "normal"

    if faq and not escalation:
        fallback = f"{faq['answer']}\n\nIs there anything else I can help you with?"
    elif faq and escalation:
        fallback = f"{faq['answer']}\n\nBecause this may need account-specific review, I recommend creating a support ticket so a human team member can follow up."
    else:
        fallback = "I don't have enough verified information to answer that reliably. I can create a support ticket for a human team member to review."

    ai_reply = gemini_answer(message, faq, escalation)
    answer = ai_reply or fallback
    return {
        "answer": answer,
        "category": category,
        "priority": priority,
        "escalation_required": escalation,
        "matched_faq": faq["title"] if faq else None,
        "mode": "gemini" if ai_reply else "demo",
        "ticket_recommended": escalation,
    }

@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse(INDEX_HTML)

@app.get("/health")
def health():
    return {"status": "ok", "app": "AI Customer Support Assistant", "gemini_enabled": bool(USE_GEMINI and GEMINI_API_KEY)}

@app.get("/api/faqs")
def list_faqs():
    return [{"id": f["id"], "title": f["title"], "answer": f["answer"]} for f in FAQS]

@app.post("/api/chat")
def chat(data: ChatRequest):
    result = compose_reply(data.message.strip())
    result["ticket_id"] = None
    if data.customer_name or data.customer_email:
        # Save a conversation as a ticket only when escalation is recommended.
        if result["escalation_required"]:
            result["ticket_id"] = create_ticket(
                message=data.message.strip(),
                customer_name=(data.customer_name or "").strip() or None,
                customer_email=(data.customer_email or "").strip() or None,
                category=result["category"],
                priority=result["priority"],
                summary=data.message.strip()[:120],
                assistant_reply=result["answer"],
            )
    return result

@app.post("/api/tickets")
def submit_ticket(data: TicketRequest):
    ticket_id = create_ticket(
        message=data.message.strip(),
        customer_name=(data.customer_name or "").strip() or None,
        customer_email=(data.customer_email or "").strip() or None,
        category=data.category.strip() or "other",
        priority=data.priority if data.priority in {"low", "normal", "high"} else "normal",
        summary=data.summary.strip() or data.message.strip()[:120],
        assistant_reply="Ticket submitted by customer.",
    )
    return {"ticket_id": ticket_id, "status": "open", "message": "Your support request has been saved."}

@app.get("/api/tickets")
def get_tickets():
    # Demo-only endpoint. Add authentication and authorization before exposing this outside localhost.
    with connect_db() as conn:
        rows = conn.execute("""
            SELECT id, created_at, customer_name, customer_email, category, priority, status, summary
            FROM tickets ORDER BY created_at DESC LIMIT 100
        """).fetchall()
    return [dict(row) for row in rows]

INDEX_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>BrightCart AI Support</title>
<style>
:root{--ink:#172033;--muted:#657089;--line:#e3e8f0;--bg:#f4f7fb;--blue:#2856d8;--soft:#eef3ff;--green:#16845b;--red:#b54732}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif}
.top{background:#101b35;color:white;padding:22px max(20px,calc((100vw - 1120px)/2));display:flex;align-items:center;justify-content:space-between;gap:12px}
.brand{font-size:20px;font-weight:750}.sub{font-size:13px;color:#c5cfe5;margin-top:4px}.pill{font-size:12px;padding:7px 10px;border:1px solid #52617e;border-radius:99px;color:#e5eaff}
.wrap{max-width:1120px;margin:28px auto;padding:0 18px;display:grid;grid-template-columns:minmax(0,1.5fr) minmax(260px,.8fr);gap:20px}
.card{background:white;border:1px solid var(--line);border-radius:16px;box-shadow:0 6px 24px #17203308;overflow:hidden}
.cardhead{padding:20px 22px;border-bottom:1px solid var(--line)}h1,h2,h3,p{margin-top:0}h1{font-size:21px;margin-bottom:5px}h2{font-size:17px;margin-bottom:6px}.muted{color:var(--muted);font-size:13px;line-height:1.5}
.messages{height:360px;overflow:auto;padding:20px;background:#fbfcfe;display:flex;flex-direction:column;gap:12px}
.msg{max-width:88%;padding:12px 14px;border-radius:14px;font-size:14px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}
.bot{align-self:flex-start;background:#edf1f7;border-bottom-left-radius:4px}.user{align-self:flex-end;background:var(--blue);color:white;border-bottom-right-radius:4px}
.meta{font-size:11px;color:var(--muted);margin-top:5px}.inputarea{padding:16px 20px;border-top:1px solid var(--line)}
textarea,input,select{width:100%;padding:11px 12px;border:1px solid #cfd7e5;border-radius:9px;font:inherit;background:white;color:var(--ink)}
textarea{min-height:78px;resize:vertical}button{border:0;border-radius:9px;padding:11px 15px;font-weight:650;cursor:pointer;background:var(--blue);color:white}button:disabled{opacity:.55;cursor:wait}.row{display:flex;gap:9px;align-items:center;margin-top:10px}.row button{white-space:nowrap}.suggestions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.suggestions button{background:white;color:#31405c;border:1px solid var(--line);font-size:12px;padding:8px 10px}
.sidebody{padding:20px}.faq{padding:12px 0;border-bottom:1px solid var(--line)}.faq:last-child{border:0}.faq strong{font-size:13px}.faq p{font-size:12px;color:var(--muted);line-height:1.5;margin:5px 0 0}.status{padding:10px 12px;border-radius:9px;background:var(--soft);color:#2546a4;font-size:12px;margin-top:12px;display:none}.ticketform{display:grid;gap:10px;margin-top:14px}.ticketform button{width:100%}.footer{text-align:center;color:var(--muted);font-size:12px;padding:0 18px 26px}.tiny{font-size:11px;color:var(--muted);line-height:1.5}
@media(max-width:780px){.wrap{grid-template-columns:1fr;margin-top:16px}.messages{height:320px}.top{padding:18px}.pill{display:none}}
</style></head>
<body>
<header class="top"><div><div class="brand">BrightCart <span style="color:#9bb5ff">AI Support</span></div><div class="sub">Customer help, powered by a policy-aware assistant</div></div><span class="pill" id="modepill">Demo mode</span></header>
<main class="wrap">
<section class="card">
<div class="cardhead"><h1>How can we help?</h1><div class="muted">Ask a question about shipping, returns, refunds, payments, or tracking.</div></div>
<div class="messages" id="messages"><div class="msg bot">Hi! I'm the BrightCart support assistant. I can answer common policy questions or help you submit a support ticket. What can I help you with today?</div></div>
<div class="inputarea"><textarea id="message" placeholder="Type your question..." maxlength="2000"></textarea><div class="row"><button id="send" onclick="sendMessage()">Send message</button><button style="background:#edf1f7;color:#26334d" onclick="clearChat()">Clear chat</button></div>
<div class="suggestions"><button onclick="ask('How long does shipping take?')">Shipping time</button><button onclick="ask('What is your return policy?')">Returns</button><button onclick="ask('When will my refund arrive?')">Refunds</button><button onclick="ask('Where is my order?')">Track order</button></div>
<div class="status" id="chatstatus"></div></div>
</section>
<aside style="display:flex;flex-direction:column;gap:20px">
<section class="card"><div class="cardhead"><h2>Help topics</h2><div class="muted">Answers are based on the sample store's published policies.</div></div><div class="sidebody" id="faqs"><div class="faq"><strong>Shipping time</strong><p>Standard shipping usually takes 3–5 business days.</p></div><div class="faq"><strong>Returns</strong><p>Unused products can be returned within 30 days with proof of purchase.</p></div><div class="faq"><strong>Refunds</strong><p>Approved refunds are generally processed within 5–7 business days.</p></div><div class="faq"><strong>Tracking</strong><p>Use the tracking link in your order confirmation. This demo cannot access real orders.</p></div></div></section>
<section class="card"><div class="cardhead"><h2>Contact support</h2><div class="muted">Create a ticket if you need a human team member.</div></div><div class="sidebody"><form class="ticketform" id="ticketform"><input id="name" placeholder="Your name (optional)" maxlength="100"><input id="email" type="email" placeholder="Email for follow-up (optional)" maxlength="254"><select id="category"><option value="other">General question</option><option value="shipping">Shipping</option><option value="returns">Returns</option><option value="refunds">Refund</option><option value="billing">Billing / payment</option><option value="product_issue">Product issue</option><option value="complaint">Complaint</option></select><select id="priority"><option value="normal">Normal priority</option><option value="high">High priority</option><option value="low">Low priority</option></select><textarea id="ticketmessage" placeholder="Describe your issue..." required minlength="2" maxlength="2000" style="min-height:90px"></textarea><button type="submit">Create support ticket</button></form><div class="status" id="ticketstatus"></div></div></section>
</aside></main>
<div class="footer">Portfolio demo using fictional company policies. Do not enter passwords, full payment-card numbers, or sensitive personal information.</div>
<script>
const messages=document.getElementById('messages');
function addMessage(text,who,meta=''){const d=document.createElement('div');d.className='msg '+who;d.textContent=text;messages.appendChild(d);if(meta){const m=document.createElement('div');m.className='meta';m.textContent=meta;d.appendChild(m)}messages.scrollTop=messages.scrollHeight;return d}
function ask(t){document.getElementById('message').value=t;sendMessage()}
function clearChat(){messages.innerHTML='';addMessage("Chat cleared. Ask me about shipping, returns, refunds, payments, or tracking.",'bot')}
document.getElementById('message').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}})
async function sendMessage(){
 const input=document.getElementById('message'),text=input.value.trim(),btn=document.getElementById('send'),status=document.getElementById('chatstatus');
 if(text.length<2)return;
 addMessage(text,'user');input.value='';btn.disabled=true;status.style.display='none';
 const wait=addMessage('Checking the support policies…','bot');
 try{
  const res=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text})});
  const data=await res.json();wait.remove();
  if(!res.ok)throw new Error(data.detail||'Request failed');
  let meta='Category: '+data.category+' · Priority: '+data.priority+' · Mode: '+data.mode;
  addMessage(data.answer,'bot',meta);
  document.getElementById('modepill').textContent=data.mode==='gemini'?'Gemini AI mode':'Demo mode';
  if(data.escalation_required){status.textContent='This question may need a human review. You can create a ticket in the Contact support panel.';status.style.display='block';document.getElementById('ticketmessage').value=text;document.getElementById('category').value=['shipping','returns','refunds','billing','product_issue','complaint'].includes(data.category)?data.category:'other';document.getElementById('priority').value=data.priority}
 }catch(err){wait.remove();addMessage('Sorry, I could not process that request. Please try again or create a support ticket.','bot');status.textContent=String(err);status.style.display='block'}
 finally{btn.disabled=false;input.focus()}
}
document.getElementById('ticketform').addEventListener('submit',async e=>{
 e.preventDefault();const status=document.getElementById('ticketstatus'),button=e.submitter;button.disabled=true;status.style.display='none';
 try{
  const payload={customer_name:document.getElementById('name').value,customer_email:document.getElementById('email').value,message:document.getElementById('ticketmessage').value,category:document.getElementById('category').value,priority:document.getElementById('priority').value,summary:document.getElementById('ticketmessage').value.slice(0,120)};
  const res=await fetch('/api/tickets',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const data=await res.json();if(!res.ok)throw new Error(data.detail||'Could not create ticket');
  status.textContent='Ticket created: '+data.ticket_id+'. Status: '+data.status+'.';status.style.display='block';
  addMessage('Your support ticket '+data.ticket_id+' has been saved. A human team member can review it. This demo does not send email notifications.','bot');
  document.getElementById('ticketmessage').value='';
 }catch(err){status.textContent='Error: '+String(err);status.style.display='block'}
 finally{button.disabled=false}
});
</script></body></html>"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=int(os.getenv("PORT", "8000")), reload=False)
