from fastapi.testclient import TestClient
import main

client = TestClient(main.app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_faq_answer():
    response = client.post("/api/chat", json={"message": "How long does shipping take?"})
    assert response.status_code == 200
    data = response.json()
    assert "3–5 business days" in data["answer"]
    assert data["category"] == "shipping"
    assert data["mode"] == "demo"

def test_unknown_question_escalates():
    response = client.post("/api/chat", json={"message": "Can you confirm my exact bank balance?"})
    assert response.status_code == 200
    data = response.json()
    assert data["escalation_required"] is True
    assert data["ticket_recommended"] is True

def test_ticket_creation():
    response = client.post("/api/tickets", json={
        "message": "My package arrived damaged",
        "category": "product_issue",
        "priority": "normal",
        "summary": "Damaged package"
    })
    assert response.status_code == 200
    data = response.json()
    assert data["ticket_id"].startswith("BC-")
    assert data["status"] == "open"
